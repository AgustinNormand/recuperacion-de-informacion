DUMP_10K_FILE = "/home/agustin/Desktop/Recuperacion/colecciones/dump10k/dump10k.txt"
INDEX_FILES_PATH = "output/"
BIN_INVERTED_INDEX_FILENAME = "inverted_index.bin"
BIN_VOCABULARY_FILENAME = "vocabulary.bin"
BIN_SKIPS_FILENAME = "skips.bin"
BIN_DGAPS_FILENAME = "dgaps.bin"
METADATA_FILE = "metadata.json"
K_SKIPS = 3

