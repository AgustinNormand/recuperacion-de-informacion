INDEX_FILES_PATH = "../script_1/output/"
BIN_INVERTED_INDEX_FILENAME = "inverted_index.bin"
BIN_VOCABULARY_FILENAME = "vocabulary.bin"
BIN_SKIPS_FILENAME = "skips.bin"
BIN_DGAPS_FILENAME = "dgaps.bin"
METADATA_FILE = "metadata.json"
K_SKIPS = 3
AND_SYMBOL = "&"
